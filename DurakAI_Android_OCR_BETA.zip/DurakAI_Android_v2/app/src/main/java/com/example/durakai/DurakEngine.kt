package com.example.durakai

enum class GameMode { PODKIDNOY, TRANSFER }

data class Card(val rank: Int, val suit: Char) {
    init { require(rank in 2..14); require(suit in listOf('C', 'D', 'H', 'S')) }
    fun beats(attacked: Card, trump: Char): Boolean =
        (suit == attacked.suit && rank > attacked.rank) ||
        (suit == trump && attacked.suit != trump)
}

sealed class Recommendation {
    data class Defend(val card: Card, val reason: String) : Recommendation()
    data class Transfer(val card: Card, val reason: String) : Recommendation()
    data class Take(val reason: String) : Recommendation()
    data class Attack(val card: Card, val reason: String) : Recommendation()
    data class ThrowIn(val card: Card, val reason: String) : Recommendation()
    data class Beat(val reason: String) : Recommendation()
}

object DurakEngine {
    /** Cheapest legal defense: avoid spending trump when a same-suit card works. */
    fun chooseDefense(hand: List<Card>, attacked: Card, trump: Char): Card? =
        hand.filter { it.beats(attacked, trump) }
            .minWithOrNull(compareBy<Card>({ if (it.suit == trump) 1 else 0 }, { it.rank }))

    /** Transfer is legal in transfer Durak only before covering, with a same-rank card. */
    fun chooseTransfer(hand: List<Card>, attacked: Card, nextPlayerCanReceive: Boolean = true): Card? {
        if (!nextPlayerCanReceive) return null
        return hand.filter { it.rank == attacked.rank }
            .minByOrNull { it.suit }
    }

    fun recommendDefense(
        hand: List<Card>, attacked: Card, trump: Char, mode: GameMode,
        nextPlayerCanReceive: Boolean = true
    ): Recommendation {
        if (mode == GameMode.TRANSFER) {
            val transfer = chooseTransfer(hand, attacked, nextPlayerCanReceive)
            if (transfer != null) return Recommendation.Transfer(transfer, "Та же достоинство: можно перевести атаку")
        }
        val defense = chooseDefense(hand, attacked, trump)
        return if (defense != null) Recommendation.Defend(defense, "Самая дешёвая подходящая карта")
        else Recommendation.Take("Нет подходящей карты для отбоя${if (mode == GameMode.TRANSFER) " или перевода" else ""}")
    }

    fun chooseAttack(hand: List<Card>): Card? =
        hand.minWithOrNull(compareBy<Card>({ if (it.rank >= 11) 1 else 0 }, { it.rank }))

    fun chooseThrowIn(hand: List<Card>, tableRanks: Set<Int>): Card? =
        hand.filter { it.rank in tableRanks }.minWithOrNull(compareBy<Card>({ it.rank >= 11 }, { it.rank }))

    fun recommendAttack(hand: List<Card>): Recommendation {
        val card = chooseAttack(hand) ?: return Recommendation.Beat("Нет карт для атаки")
        return Recommendation.Attack(card, "Начни с младшей карты, сохранив старшие")
    }
}
