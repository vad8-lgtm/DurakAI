package com.example.durakai

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val captureRequest = 410
    private lateinit var status: TextView
    private lateinit var mode: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
        }
        val title = TextView(this).apply {
            text = "🂡 Durak AI"
            textSize = 27f
        }
        val subtitle = TextView(this).apply {
            text = "Помощник для подкидного и переводного дурака"
            textSize = 16f
        }
        val modeLabel = TextView(this).apply {
            text = "Режим игры:"
            textSize = 17f
            setPadding(0, 24, 0, 6)
        }
        mode = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Подкидной дурак", "Переводной дурак"))
        }
        status = TextView(this).apply {
            text = "Выбери режим, разреши плавающее окно и запусти помощника.\n\nПосле запуска Android попросит разрешение на захват экрана."
            textSize = 16f
            setPadding(0, 22, 0, 16)
        }
        val overlay = Button(this).apply {
            text = "Разрешить плавающее окно"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else status.text = "Разрешение на плавающее окно уже есть."
            }
        }
        val start = Button(this).apply {
            text = "Запустить помощника"
            setOnClickListener { requestCapture() }
        }
        val stop = Button(this).apply {
            text = "Остановить помощника"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                stopService(Intent(this@MainActivity, OverlayService::class.java))
                status.text = "Помощник остановлен."
            }
        }
        listOf(title, subtitle, modeLabel, mode, status, overlay, start, stop).forEach {
            layout.addView(it, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        setContentView(layout)
    }

    private fun requestCapture() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Сначала разреши отображение поверх других приложений."
            return
        }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("Deprecated API retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == Activity.RESULT_OK && data != null) {
            val selectedMode = if (mode.selectedItemPosition == 1) "TRANSFER" else "PODKIDNOY"
            val capture = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("data", data)
                putExtra("gameMode", selectedMode)
            }
            startService(capture)
            startService(Intent(this, OverlayService::class.java).putExtra("gameMode", selectedMode))
            status.text = "Захват экрана включён. Режим: ${mode.selectedItem}. Открой игру."
        } else status.text = "Захват экрана не разрешён."
    }
}
