package com.example.durakai

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var lastAnalysis = 0L
    private var gameMode = GameMode.PODKIDNOY

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotification()
        val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        val mode = intent.getStringExtra("gameMode") ?: "PODKIDNOY"
        gameMode = if (mode == "TRANSFER") GameMode.TRANSFER else GameMode.PODKIDNOY
        OverlayService.updateHint(if (mode == "TRANSFER") "Режим: переводной · анализирую экран…" else "Режим: подкидной · анализирую экран…")
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        thread = HandlerThread("DurakScreenCapture").also { it.start() }
        reader = ImageReader.newInstance(width, height, android.graphics.PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ source ->
            val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = System.currentTimeMillis()
                if (now - lastAnalysis > 1200) {
                    lastAnalysis = now
                    val plane = image.planes[0]
                    val fullWidth = plane.rowStride / plane.pixelStride
                    val full = Bitmap.createBitmap(fullWidth, height, Bitmap.Config.ARGB_8888)
                    full.copyPixelsFromBuffer(plane.buffer)
                    val frame = Bitmap.createBitmap(full, 0, 0, width, height)
                    full.recycle()
                    CardScreenAnalyzer.analyze(frame) { result ->
                        OverlayService.updateHint(makeAdvice(result))
                        frame.recycle()
                    }
                }
            } catch (_: Exception) {
                OverlayService.updateHint("Ошибка чтения кадра. Перезапусти захват экрана.")
            } finally { image.close() }
        }, Handler(thread!!.looper))
        display = projection?.createVirtualDisplay("DurakAI", width, height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null)
        return START_STICKY
    }


    private fun makeAdvice(r: CardScreenAnalyzer.Result): String {
        if (r.hand.isEmpty()) return "Не удалось прочитать карты руки. Попробуй развернуть игру на весь экран."
        val handText = r.hand.joinToString(" ") { it.label() }
        val tableText = r.table.joinToString(" ") { it.label() }
        if (r.turn == null) return "Рука: $handText\nСтол: ${tableText.ifBlank { "не распознан" }}\nНе распознал фазу хода — проверь вручную."
        val advice = when (r.turn) {
            "DEFEND" -> {
                val attacked = r.table.lastOrNull()
                if (attacked == null || r.trump == null) "Не распознана атакующая карта или козырь. Не буду угадывать."
                else when (val rec = DurakEngine.recommendDefense(r.hand, attacked, r.trump, gameMode)) {
                    is Recommendation.Transfer -> "ПЕРЕВОД: ${rec.card.label()}"
                    is Recommendation.Defend -> "ОТБИВАЙСЯ: ${rec.card.label()}"
                    is Recommendation.Take -> "БЕРИ: ${rec.reason}"
                    else -> "Проверь карты вручную."
                }
            }
            "ATTACK" -> when (val rec = DurakEngine.recommendAttack(r.hand)) {
                is Recommendation.Attack -> "АТАКА: ${rec.card.label()}"
                else -> "БИТО"
            }
            "THROW" -> {
                val card = DurakEngine.chooseThrowIn(r.hand, r.table.map { it.rank }.toSet())
                if (card == null) "БИТО — нечего подкинуть" else "ПОДКИНЬ: ${card.label()}"
            }
            else -> "Ожидаю ход…"
        }
        return "$advice\nРука: $handText"
    }
    private fun Card.label(): String {
        val r = when(rank) { 11 -> "В"; 12 -> "Д"; 13 -> "К"; 14 -> "Т"; else -> rank.toString() }
        val s = when(suit) { 'C' -> "♣"; 'D' -> "♦"; 'H' -> "♥"; else -> "♠" }
        return r+s
    }

    private fun createNotification() {
        val channelId = "durakai_capture"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Durak AI screen capture", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId)
                      else @Suppress("DEPRECATION") Notification.Builder(this)
        val notification = builder.setContentTitle("Durak AI работает")
            .setContentText("Захват экрана активен по твоему разрешению")
            .setSmallIcon(android.R.drawable.ic_menu_info_details).build()
        startForeground(7, notification)
    }

    override fun onDestroy() {
        display?.release(); reader?.close(); projection?.stop(); thread?.quitSafely()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
