\
package com.example.durakai

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale

/** OCR reader tuned to the card positions in the supplied game screenshots. */
object CardScreenAnalyzer {
    data class ReadCard(val card: Card, val x: Int, val y: Int, val region: Region)
    enum class Region { HAND, TABLE, TRUMP }
    data class Result(val hand: List<Card>, val table: List<Card>, val trump: Char?, val turn: String?, val debug: String)
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val rankRegex = Regex("(?i)(10|[2-9]|[AJQK])")
    private val suits = mapOf("♣" to 'C', "♧" to 'C', "♦" to 'D', "♢" to 'D', "♥" to 'H', "♡" to 'H', "♠" to 'S', "♤" to 'S', "CLUB" to 'C', "DIAMOND" to 'D', "HEART" to 'H', "SPADE" to 'S')

    fun analyze(bitmap: Bitmap, callback: (Result) -> Unit) {
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { vision ->
                val w = bitmap.width; val h = bitmap.height
                val found = mutableListOf<ReadCard>(); val debug = StringBuilder()
                for (block in vision.textBlocks) for (line in block.lines) {
                    val b = line.boundingBox ?: continue
                    val t = line.text.uppercase(Locale.ROOT)
                    debug.append(t).append(" @").append(b.centerX()).append(',').append(b.centerY()).append('\n')
                    val rank = parseRank(t) ?: continue
                    val suit = parseSuit(t) ?: continue
                    val x = b.centerX(); val y = b.centerY()
                    val region = when {
                        y > h * 0.60 -> Region.HAND
                        x < w * 0.27 && y in (h * 0.30).toInt()..(h * 0.62).toInt() -> Region.TRUMP
                        y in (h * 0.28).toInt()..(h * 0.61).toInt() -> Region.TABLE
                        else -> null
                    } ?: continue
                    found.add(ReadCard(Card(rank, suit), x, y, region))
                }
                fun cards(region: Region) = found.filter { it.region == region }.sortedBy { it.x }
                    .fold(mutableListOf<ReadCard>()) { acc, c -> if (acc.none { it.card == c.card && kotlin.math.abs(it.x-c.x)<36 && kotlin.math.abs(it.y-c.y)<36 }) acc.add(c); acc }
                val allText = vision.text.uppercase(Locale.ROOT)
                val turn = when {
                    "ОТБЕЙТЕСЬ" in allText || "ОТБЕИТЕСЬ" in allText -> "DEFEND"
                    "АТАКУЙТЕ" in allText -> "ATTACK"
                    "ВСЁ ОТБИТО" in allText || "ВСЕ ОТБИТО" in allText -> "THROW"
                    else -> null
                }
                callback(Result(cards(Region.HAND).map { it.card }, cards(Region.TABLE).map { it.card }, cards(Region.TRUMP).firstOrNull()?.card?.suit, turn, debug.toString()))
            }
            .addOnFailureListener { callback(Result(emptyList(), emptyList(), null, null, "OCR: ${it.message}")) }
    }
    private fun parseRank(text: String): Int? {
        val token = rankRegex.find(text.replace('O','0'))?.value?.uppercase(Locale.ROOT) ?: return null
        return when(token) { "A" -> 14; "K" -> 13; "Q" -> 12; "J" -> 11; "10" -> 10; else -> token.toIntOrNull() }?.takeIf { it in 2..14 }
    }
    private fun parseSuit(text: String): Char? = suits.entries.firstOrNull { text.contains(it.key) }?.value
}
