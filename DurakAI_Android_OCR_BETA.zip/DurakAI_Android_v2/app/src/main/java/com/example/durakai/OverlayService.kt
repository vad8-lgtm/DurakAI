package com.example.durakai

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {
    companion object {
        @Volatile private var hint: TextView? = null
        fun updateHint(message: String) { hint?.post { hint?.text = "Durak AI\n$message" } }
    }
    private var windowManager: WindowManager? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (hint != null) return START_STICKY
        val mode = intent?.getStringExtra("gameMode") ?: "PODKIDNOY"
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = TextView(this).apply {
            text = if (mode == "TRANSFER") "Durak AI\nПереводной режим\nОжидаю карты…" else "Durak AI\nПодкидной режим\nОжидаю карты…"
            textSize = 13f; setTextColor(0xFFFFFFFF.toInt())
            setPadding(22, 16, 22, 16); setBackgroundColor(0xE622332C.toInt())
        }
        hint = view
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 150 }
        windowManager?.addView(view, params)
        return START_STICKY
    }
    override fun onDestroy() {
        try { if (hint != null) windowManager?.removeView(hint) } catch (_: Exception) {}
        hint = null; super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
